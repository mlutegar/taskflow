export const taskKeys = {
  all: ["tasks"] as const,
  lists: () => [...taskKeys.all, "list"] as const,
  list: (
    filter?: string,
    sort?: string,
    projectId?: string,
    time?: string,
    assignedTo?: string,
    priorities?: string,
    dueFilter?: string
  ) =>
    [
      ...taskKeys.lists(),
      filter || "all",
      sort || "default",
      projectId || "all-projects",
      time || "all-times",
      assignedTo || "all-assigned",
      priorities || "all-priorities",
      dueFilter || "all-due",
    ] as const,
  completedToday: () => [...taskKeys.all, "completed-today"] as const,
  mutations: () => [...taskKeys.all, "mutation"] as const,
  mutation: (name: string) => [...taskKeys.mutations(), name] as const,
};
