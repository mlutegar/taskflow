/**
 * customModes.js — Gerenciamento centralizado de modos customizados.
 * Persiste em localStorage + sync com backend (fire-and-forget, retry offline).
 *
 * Rastreia `deletedModeIds` para evitar que modos deletados voltem ao fazer merge remoto.
 */

import { withOfflineFallback } from "./syncQueue";
import type { Mode } from "../types/index";

const LS_MODES   = "customModes";          // sem prefixo taskflow. (legado)
const LS_DELETED = "taskflow.deletedModeIds";
const LS_HIDDEN  = "taskflow.hiddenModeIds";

// ── Leitura ───────────────────────────────────────────────────────────────────

/** Retorna todos os modos customizados do usuário. */
export function getCustomModes(): Mode[] {
  try {
    const raw = localStorage.getItem(LS_MODES);
    if (!raw) return [];
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

/** Retorna o Set de IDs de modos que o usuário deletou. */
export function getDeletedModeIds(): Set<string> {
  try {
    const raw = localStorage.getItem(LS_DELETED);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

/** Retorna o Set de IDs de modos que o usuário ocultou (reversível). */
export function getHiddenModeIds(): Set<string> {
  try {
    const raw = localStorage.getItem(LS_HIDDEN);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

// ── Escrita ───────────────────────────────────────────────────────────────────

function _persistModes(modes: Mode[]): void {
  try { localStorage.setItem(LS_MODES, JSON.stringify(modes)); } catch {}
}

function _persistDeleted(ids: Set<string>): void {
  try { localStorage.setItem(LS_DELETED, JSON.stringify([...ids])); } catch {}
}

function _syncToBackend(modes: Mode[], deletedIds: Set<string>): void {
  withOfflineFallback("PUT", "/preferences", {
    customModes:    modes,
    deletedModeIds: [...deletedIds],
  });
}

/** Adiciona um novo modo customizado. */
export function saveCustomMode(newMode: Mode): Mode[] | undefined {
  if (!newMode?.id) return;
  const modes = getCustomModes().filter((m) => m.id !== newMode.id);
  const updated = [...modes, newMode];
  _persistModes(updated);

  // Remove da lista de deletados (caso seja recriação)
  const deleted = getDeletedModeIds();
  deleted.delete(newMode.id);
  _persistDeleted(deleted);

  _syncToBackend(updated, deleted);
  return updated;
}

// ── Modos ocultos (reversível) ─────────────────────────────────────────────────

function _persistHidden(ids: Set<string>): void {
  try { localStorage.setItem(LS_HIDDEN, JSON.stringify([...ids])); } catch {}
}

/** Persiste os modos ocultos e sincroniza com o backend. */
export function setHiddenModeIds(ids: Set<string>): void {
  _persistHidden(ids);
  withOfflineFallback("PUT", "/preferences", { hiddenModeIds: [...ids] });
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("hiddenModesUpdated"));
  }
}

/** Alterna o estado "oculto" de um modo. Retorna o novo Set. */
export function toggleHiddenMode(id: string): Set<string> {
  const hidden = getHiddenModeIds();
  if (hidden.has(id)) hidden.delete(id);
  else hidden.add(id);
  setHiddenModeIds(hidden);
  return hidden;
}

/** Remove um modo customizado pelo ID. */
export function deleteCustomMode(id: string): Mode[] | undefined {
  if (!id) return;
  const updated = getCustomModes().filter((m) => m.id !== id);
  _persistModes(updated);

  // Marca como deletado para o merge remoto ignorar
  const deleted = getDeletedModeIds();
  deleted.add(id);
  _persistDeleted(deleted);

  _syncToBackend(updated, deleted);
  return updated;
}
