interface PresetCombo {
  id: string;
  name: string;
  emoji: string;
  description: string;
  situation: string;
  modeIds: string[];
  color: string;
  colorBg: string;
}

export const PRESET_COMBOS: PresetCombo[] = [
  {
    id: "dia_dificil",
    name: "Dia Difícil",
    emoji: "💙",
    description: "Música cria o ambiente sem esforço; TikTok Fixo oferece recompensa previsível e simples — sem escalada, sem pressão.",
    situation: "Quando você está sem energia e precisa de uma sessão gentil",
    modeIds: ["music_album", "tiktok_fixed"],
    color: "#4ea8cc",
    colorBg: "rgba(78,168,204,0.08)",
  },
  {
    id: "sprint_pesado",
    name: "Sprint Pesado",
    emoji: "🔥",
    description: "Cafeína rastreada + timer definido = extração máxima de energia em blocos mensuráveis de alto rendimento.",
    situation: "Quando você tem prazo e alta energia disponível",
    modeIds: ["espresso", "pomodoro"],
    color: "#c8874a",
    colorBg: "rgba(200,135,74,0.08)",
  },
  {
    id: "no_transporte",
    name: "No Transporte",
    emoji: "🚇",
    description: "Tab Hop distribui o foco entre apps com intenção; Playlist elimina a busca por música — dois sistemas para momentos fragmentados.",
    situation: "Em deslocamento onde foco longo não é possível",
    modeIds: ["tabhop", "playlist_fixed"],
    color: "#2d9bf0",
    colorBg: "rgba(45,155,240,0.08)",
  },
  {
    id: "destravar",
    name: "Destravar Agora",
    emoji: "🧱",
    description: "Cantar reseta o estado emocional em poucos minutos; Momentum dá o primeiro passo com apenas 5 minutos — bloqueio quebrado em duas etapas.",
    situation: "Quando você está completamente travado e sem saber por onde começar",
    modeIds: ["cantar", "momentum"],
    color: "#e0679b",
    colorBg: "rgba(224,103,155,0.08)",
  },
  {
    id: "foco_maximo",
    name: "Foco Máximo",
    emoji: "🧊",
    description: "Cold Turkey elimina todas as distrações de uma vez; Pomodoro define o bloco de trabalho com clareza — ambiente + tempo.",
    situation: "Quando você precisa de foco total sem distrações — modo nuclear",
    modeIds: ["cold_turkey", "pomodoro"],
    color: "#1565c0",
    colorBg: "rgba(21,101,192,0.08)",
  },
  {
    id: "recuperacao",
    name: "Recuperação",
    emoji: "🌿",
    description: "Caminhar libera tensão física acumulada; Meditar restaura a clareza mental — dupla de recuperação completa antes de voltar ao trabalho.",
    situation: "Quando você está esgotado e precisa recarregar antes de continuar",
    modeIds: ["caminhar", "meditar"],
    color: "#43a047",
    colorBg: "rgba(67,160,71,0.08)",
  },
  {
    id: "gamificado",
    name: "Dia Gamificado",
    emoji: "🎮",
    description: "RPG transforma tarefas em quests com XP; Gamer Mode usa partidas reais como recompensa — dopamina controlada em dobro.",
    situation: "Quando o trabalho parece monótono e você precisa de estímulo lúdico",
    modeIds: ["rpg", "gamer_fixed"],
    color: "#7b2fff",
    colorBg: "rgba(123,47,255,0.08)",
  },
  {
    id: "manha_produtiva",
    name: "Manhã Produtiva",
    emoji: "🌅",
    description: "Morning Routine ancora rituais de início do dia; Espresso maximiza a energia do primeiro café — base ideal para uma sessão de pico.",
    situation: "Para começar o dia com máxima intenção e energia",
    modeIds: ["morning_routine", "espresso"],
    color: "#f9a825",
    colorBg: "rgba(249,168,37,0.08)",
  },
  {
    id: "recuperacao_completa",
    name: "Recuperação Completa",
    emoji: "🛁",
    description: "Power nap de 15 minutos restaura o estágio 2 do sono; banho quente em seguida relaxa a musculatura e sinaliza ao cérebro a transição para descanso real.",
    situation: "Após dias intensos ou quando a energia está no limite",
    modeIds: ["soneca_15", "tomar_banho"],
    color: "#5c6bc0",
    colorBg: "rgba(92,107,192,0.08)",
  },
  {
    id: "reset_mental",
    name: "Reset Mental",
    emoji: "🧘",
    description: "Respiração 4-7-8 derruba o cortisol em 90 segundos; meditação consolida o estado de calma — dupla de reset antes de retomar trabalho denso.",
    situation: "Quando ansiedade ou overthinking estão travando o trabalho",
    modeIds: ["respiracao", "meditar"],
    color: "#4ea8cc",
    colorBg: "rgba(78,168,204,0.08)",
  },
];
