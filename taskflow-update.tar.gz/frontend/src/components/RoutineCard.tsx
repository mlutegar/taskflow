import { useState, memo } from "react";
import styles from "./RoutineCard.module.css";

const TODAY = new Date().toISOString().split("T")[0];

function yesterday(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().split("T")[0];
}

interface ChecklistItem {
  id: string | number;
  description: string;
  completed: boolean;
}

interface Routine {
  id: string | number;
  title: string;
  description?: string | null;
  target_value?: number | null;
  unit?: string | null;
  progress_percentage?: number | null;
  current_progress?: number | null;
  is_completed_today: boolean;
  recurrence?: string | null;
  checklist_count?: number;
  checklist_completed_count?: number;
  checklist: ChecklistItem[];
  completion_history: string[];
  updatedAt?: string;
  updated_at?: string;
}

interface RoutineCardProps {
  routine: Routine;
  onComplete: (id: string | number) => void;
  onUncomplete: (id: string | number) => void;
  onCompleteForDate: (id: string | number, date: string) => Promise<void>;
  onDelete: (id: string | number) => void;
  onUpdate: (
    id: string | number,
    data: {
      title: string;
      description: string | null;
      target_value: number | null;
      unit: string | null;
    }
  ) => Promise<void>;
  onAddProgress: (id: string | number, value: number) => Promise<void>;
  onAddChecklist: (id: string | number, description: string) => Promise<void>;
  onToggleChecklist: (routineId: string | number, itemId: string | number) => void;
  onDeleteChecklist: (routineId: string | number, itemId: string | number) => void;
}

interface EditData {
  title: string;
  description: string;
  target_value: number | string;
  unit: string;
}

function RoutineCard({
  routine,
  onComplete,
  onUncomplete,
  onCompleteForDate,
  onDelete,
  onUpdate,
  onAddProgress,
  onAddChecklist,
  onToggleChecklist,
  onDeleteChecklist,
}: RoutineCardProps) {
  const [expanded, setExpanded] = useState<boolean>(false);
  const [editing, setEditing] = useState<boolean>(false);
  const [editData, setEditData] = useState<EditData>({
    title: routine.title,
    description: routine.description || "",
    target_value: routine.target_value ?? "",
    unit: routine.unit || "",
  });
  const [progressInput, setProgressInput] = useState<string>("");
  const [checklistInput, setChecklistInput] = useState<string>("");
  const [saving, setSaving] = useState<boolean>(false);
  const [showDatePicker, setShowDatePicker] = useState<boolean>(false);
  const [pastDate, setPastDate] = useState<string>(yesterday);

  const hasTarget = routine.target_value != null;
  const pct = routine.progress_percentage ?? 0;

  const handleSaveEdit = async (): Promise<void> => {
    setSaving(true);
    try {
      await onUpdate(routine.id, {
        title: editData.title.trim(),
        description: (editData.description as string).trim() || null,
        target_value: editData.target_value !== "" ? Number(editData.target_value) : null,
        unit: (editData.unit as string).trim() || null,
      });
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const handleAddProgress = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    const val = parseFloat(progressInput);
    if (isNaN(val) || val <= 0) return;
    await onAddProgress(routine.id, val);
    setProgressInput("");
  };

  const handleAddChecklist = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!checklistInput.trim()) return;
    await onAddChecklist(routine.id, checklistInput.trim());
    setChecklistInput("");
  };

  if (editing) {
    return (
      <div className={styles.card}>
        <div className={styles.editForm}>
          <input
            className={styles.editInput}
            value={editData.title}
            onChange={(e) => setEditData((d) => ({ ...d, title: e.target.value }))}
            placeholder="Título"
            autoFocus
          />
          <textarea
            className={styles.editTextarea}
            value={editData.description}
            onChange={(e) => setEditData((d) => ({ ...d, description: e.target.value }))}
            placeholder="Descrição (opcional)"
            rows={2}
          />
          <div className={styles.editRow}>
            <input
              type="number"
              className={styles.editInput}
              value={editData.target_value as string}
              onChange={(e) => setEditData((d) => ({ ...d, target_value: e.target.value }))}
              placeholder="Meta (ex: 4.5)"
              min="0"
              step="0.1"
            />
            <input
              className={styles.editInput}
              value={editData.unit}
              onChange={(e) => setEditData((d) => ({ ...d, unit: e.target.value }))}
              placeholder="Unidade (ex: L, hrs)"
            />
          </div>
          <div className={styles.editActions}>
            <button className={styles.btnSave} onClick={handleSaveEdit} disabled={saving || !editData.title.trim()}>
              {saving ? "Salvando..." : "Salvar"}
            </button>
            <button className={styles.btnCancel} onClick={() => setEditing(false)}>Cancelar</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`${styles.card} ${routine.is_completed_today ? styles.done : ""}`}>
      <div className={styles.main}>
        <button
          className={`${styles.checkBtn} ${routine.is_completed_today ? styles.checkDone : ""}`}
          onClick={() => !routine.is_completed_today && onComplete(routine.id)}
          title={routine.is_completed_today ? "Concluída hoje" : "Marcar como concluída"}
          aria-label={routine.is_completed_today ? "Rotina concluída hoje" : "Marcar rotina como concluída"}
          disabled={routine.is_completed_today}
        >
          {routine.is_completed_today && "✓"}
        </button>

        <div
          className={styles.content}
          onClick={() => setExpanded((v) => !v)}
          role="button"
          tabIndex={0}
          aria-expanded={expanded}
          aria-label={`${routine.title} — clique para ${expanded ? "recolher" : "expandir"} detalhes`}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setExpanded((v) => !v); } }}
        >
          <div className={styles.titleRow}>
            <span className={styles.title}>{routine.title}</span>
            {routine.recurrence === "daily" && (
              <span className={styles.badge} title="Recorrência diária">🔁 diária</span>
            )}
            {routine.recurrence === "weekdays" && (
              <span className={styles.badge} title="Somente dias úteis (seg–sex)">🔁 dias úteis</span>
            )}
            <span className={`${styles.badge} ${routine.is_completed_today ? styles.badgeDone : styles.badgePending}`}>
              {routine.is_completed_today ? "✓ Hoje" : "Pendente"}
            </span>
          </div>

          {hasTarget && (
            <div className={styles.progressWrap}>
              <div className={styles.progressBar}>
                <div className={styles.progressFill} style={{ width: `${pct}%` }} />
              </div>
              <span className={styles.progressLabel}>
                {routine.current_progress}/{routine.target_value} {routine.unit || ""} · {pct.toFixed(0)}%
              </span>
            </div>
          )}

          {!hasTarget && (routine.checklist_count ?? 0) > 0 && (
            <div className={styles.meta}>
              <span>☑ {routine.checklist_completed_count}/{routine.checklist_count} itens</span>
            </div>
          )}
        </div>

        <div className={styles.actions}>
          {routine.is_completed_today && (
            <button className={`${styles.actionBtn} ${styles.uncompleteBtn}`} onClick={() => onUncomplete(routine.id)} title="Desfazer conclusão" aria-label="Desfazer conclusão de rotina">↩</button>
          )}
          <button
            className={`${styles.actionBtn} ${showDatePicker ? styles.datePickerBtnActive : ""}`}
            onClick={() => setShowDatePicker((v) => !v)}
            title="Marcar como feito em outro dia"
            aria-label="Marcar como feito em outra data"
          >
            📅
          </button>
          <button className={styles.actionBtn} onClick={() => setEditing(true)} title="Editar" aria-label="Editar rotina">✏️</button>
          <button className={`${styles.actionBtn} ${styles.deleteBtn}`} onClick={() => onDelete(routine.id)} title="Deletar" aria-label="Deletar rotina">🗑</button>
        </div>
      </div>

      {showDatePicker && (
        <div className={styles.datePickerRow}>
          <span className={styles.datePickerLabel}>Marcar como feito em:</span>
          <input
            type="date"
            className={styles.datePickerInput}
            value={pastDate}
            max={TODAY}
            onChange={(e) => setPastDate(e.target.value)}
          />
          <button
            className={styles.datePickerConfirm}
            disabled={!pastDate || routine.completion_history.includes(pastDate)}
            onClick={async () => {
              await onCompleteForDate(routine.id, pastDate);
              setShowDatePicker(false);
            }}
          >
            {routine.completion_history.includes(pastDate) ? "Já marcado" : "Confirmar"}
          </button>
          <button className={styles.datePickerCancel} onClick={() => setShowDatePicker(false)}>Cancelar</button>
        </div>
      )}

      {expanded && (
        <div className={styles.detail}>
          {routine.description && <p className={styles.description}>{routine.description}</p>}

          {hasTarget && !routine.is_completed_today && (
            <form className={styles.progressForm} onSubmit={handleAddProgress}>
              <input
                type="number"
                className={styles.progressInput}
                value={progressInput}
                onChange={(e) => setProgressInput(e.target.value)}
                placeholder={`Adicionar ${routine.unit || "progresso"}...`}
                min="0.01"
                step="0.01"
              />
              <button type="submit" className={styles.progressAddBtn} disabled={!progressInput}>
                + Progresso
              </button>
            </form>
          )}

          {(routine.checklist.length > 0 || !routine.is_completed_today) && (
            <div className={styles.checklist}>
              {routine.checklist.map((item) => (
                <div key={item.id} className={styles.checklistItem}>
                  <button
                    className={`${styles.checklistCheck} ${item.completed ? styles.checklistDone : ""}`}
                    onClick={() => onToggleChecklist(routine.id, item.id)}
                  >
                    {item.completed && "✓"}
                  </button>
                  <span className={item.completed ? styles.checklistTextDone : ""}>{item.description}</span>
                  <button
                    className={styles.checklistDelete}
                    onClick={() => onDeleteChecklist(routine.id, item.id)}
                    aria-label="Remover item do checklist"
                  >✕</button>
                </div>
              ))}

              {!routine.is_completed_today && (
                <form className={styles.checklistForm} onSubmit={handleAddChecklist}>
                  <input
                    className={styles.checklistInput}
                    value={checklistInput}
                    onChange={(e) => setChecklistInput(e.target.value)}
                    placeholder="Adicionar item ao checklist..."
                  />
                  <button type="submit" className={styles.checklistAdd} disabled={!checklistInput.trim()}>+</button>
                </form>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default memo(RoutineCard, (prev, next) => {
  return prev.routine.id === next.routine.id &&
    prev.routine.updatedAt === next.routine.updatedAt &&
    prev.routine.updated_at === next.routine.updated_at &&
    prev.routine.is_completed_today === next.routine.is_completed_today;
});
