import { supabase } from "../lib/supabase";

const RECURRENCE_DAYS = { daily: 1, weekly: 7, biweekly: 14 };

function computeNextDueDate(currentDueDate, recurrence) {
  const base = currentDueDate
    ? new Date(currentDueDate + "T12:00:00")
    : new Date();
  if (recurrence === "monthly") {
    base.setMonth(base.getMonth() + 1);
  } else {
    base.setDate(base.getDate() + (RECURRENCE_DAYS[recurrence] ?? 7));
  }
  return base.toISOString().split("T")[0];
}

function shapeTask(task) {
  const checklist = (task.checklist ?? []).sort((a, b) => a.order - b.order || a.id - b.id);
  return {
    ...task,
    checklist,
    checklist_count: checklist.length,
    checklist_completed_count: checklist.filter((c) => c.completed).length,
  };
}

function throwIfError(error) {
  if (error) throw new Error(error.message);
}

export const tasksApi = {
  list: async (params = {}) => {
    let query = supabase.from("tasks").select("*, checklist:checklist_items(*)");

    if (params.status === "active") query = query.eq("completed", false);
    else if (params.status === "completed") query = query.eq("completed", true);

    if (params.sort === "due_date_asc" || params.sort === "due_date") {
      query = query.order("due_date", { ascending: true, nullsFirst: false }).order("priority");
    } else if (params.sort === "due_date_desc") {
      query = query.order("due_date", { ascending: false, nullsFirst: false }).order("priority");
    } else if (params.sort === "overdue") {
      // busca tudo e ordena no client: vencidas primeiro, depois por proximidade
      query = query.order("due_date", { nullsFirst: false }).order("priority");
    } else if (params.sort === "created") {
      query = query.order("created_at", { ascending: false });
    } else {
      query = query.order("priority").order("created_at", { ascending: false });
    }

    const { data, error } = await query;
    throwIfError(error);
    return data.map(shapeTask);
  },

  create: async (data) => {
    const { data: task, error } = await supabase
      .from("tasks")
      .insert(data)
      .select("*, checklist:checklist_items(*)")
      .single();
    throwIfError(error);
    return shapeTask(task);
  },

  update: async (id, data) => {
    const { data: task, error } = await supabase
      .from("tasks")
      .update(data)
      .eq("id", id)
      .select("*, checklist:checklist_items(*)")
      .single();
    throwIfError(error);
    return shapeTask(task);
  },

  delete: async (id) => {
    const { error } = await supabase.from("tasks").delete().eq("id", id);
    throwIfError(error);
    return null;
  },

  complete: (id, currentTask) => {
    const completedAt = new Date().toISOString();
    if (currentTask?.recurrence) {
      const nextDate = computeNextDueDate(currentTask.due_date, currentTask.recurrence);
      return tasksApi.update(id, { due_date: nextDate, completed: false, completed_at: completedAt });
    }
    return tasksApi.update(id, { completed: true, completed_at: completedAt });
  },

  reopen: (id) => tasksApi.update(id, { completed: false, completed_at: null }),

  /** Tarefas ativas com vencimento hoje — para sugestão rápida no Daily Focus. */
  listDueToday: async () => {
    const today = new Date().toISOString().split("T")[0];
    const { data, error } = await supabase
      .from("tasks")
      .select("id, title, priority, due_date")
      .eq("completed", false)
      .eq("due_date", today)
      .order("priority")
      .limit(10);
    if (error) return [];
    return data ?? [];
  },

  // Quantas tarefas foram concluídas hoje (independente de já terem sido reabertas
  // ou reagendadas como recorrentes — conta pelo carimbo de conclusão).
  countCompletedToday: async () => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const { count, error } = await supabase
      .from("tasks")
      .select("id", { count: "exact", head: true })
      .gte("completed_at", start.toISOString());
    throwIfError(error);
    return count ?? 0;
  },

  addChecklistItem: async (taskId, description, parentId = null) => {
    // ordem é calculada entre os irmãos (mesmo task_id e mesmo parent_id)
    let countQuery = supabase
      .from("checklist_items")
      .select("id")
      .eq("task_id", taskId);
    countQuery = parentId == null
      ? countQuery.is("parent_id", null)
      : countQuery.eq("parent_id", parentId);
    const { data: existing } = await countQuery;
    const order = existing?.length ?? 0;

    const { data, error } = await supabase
      .from("checklist_items")
      .insert({ task_id: taskId, parent_id: parentId, description, order })
      .select()
      .single();
    throwIfError(error);
    return data;
  },

  updateChecklistItem: async (_taskId, itemId, fields) => {
    // Aceita string (legado = só descrição) ou objeto { description?, note? }
    const updates = typeof fields === "string" ? { description: fields } : fields;
    const { data, error } = await supabase
      .from("checklist_items")
      .update(updates)
      .eq("id", itemId)
      .select()
      .single();
    throwIfError(error);
    return data;
  },

  toggleChecklistItem: async (_taskId, itemId) => {
    const { data: current, error: fetchError } = await supabase
      .from("checklist_items")
      .select("completed")
      .eq("id", itemId)
      .single();
    throwIfError(fetchError);

    const { data, error } = await supabase
      .from("checklist_items")
      .update({ completed: !current.completed })
      .eq("id", itemId)
      .select()
      .single();
    throwIfError(error);
    return data;
  },

  deleteChecklistItem: async (_taskId, itemId) => {
    const { error } = await supabase.from("checklist_items").delete().eq("id", itemId);
    throwIfError(error);
    return null;
  },
};
