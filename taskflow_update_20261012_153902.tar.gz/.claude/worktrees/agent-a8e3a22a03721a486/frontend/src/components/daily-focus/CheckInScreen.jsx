import { useState } from "react";
import { ESTADOS } from "./stateToMode";
import styles from "./CheckInScreen.module.css";

/**
 * Recebe uma lista de modos disponíveis (ALL_MODES) para resolver emoji/nome.
 * Props:
 *   allModes   — array de { id, emoji, name, tagline }
 *   onSelect   — (modeId, estadoId) → void  — usuário escolheu um modo
 *   onSkip     — () → void        — usuário pulou o check-in
 */
export default function CheckInScreen({ allModes = [], onSelect, onSkip }) {
  const [selectedEstado, setSelectedEstado] = useState(null);
  const [showAlt, setShowAlt] = useState(false);

  function getModeInfo(modeId) {
    return allModes.find((m) => m.id === modeId) || null;
  }

  function handleEstadoClick(estado) {
    if (selectedEstado?.id === estado.id) {
      setSelectedEstado(null);
      setShowAlt(false);
    } else {
      setSelectedEstado(estado);
      setShowAlt(false);
    }
  }

  const mainMode = selectedEstado ? getModeInfo(selectedEstado.modeId) : null;
  const altMode  = selectedEstado ? getModeInfo(selectedEstado.modeIdAlt) : null;

  return (
    <div className={styles.wrap}>
      {/* Título */}
      <div>
        <div className={styles.title}>Como você está agora?</div>
        <div className={styles.sub}>
          Escolha seu estado atual e veja o modo de apoio mais adequado para o momento.
        </div>
      </div>

      {/* Grade de estados */}
      <div className={styles.grid}>
        {ESTADOS.map((estado) => (
          <button
            key={estado.id}
            className={`${styles.estadoBtn} ${selectedEstado?.id === estado.id ? styles.estadoBtnActive : ""}`}
            onClick={() => handleEstadoClick(estado)}
          >
            <span className={styles.estadoEmoji}>{estado.emoji}</span>
            <span className={styles.estadoLabel}>{estado.label}</span>
          </button>
        ))}
      </div>

      {/* Card de recomendação */}
      {selectedEstado && mainMode && (
        <div className={styles.recoCard}>
          {/* Header */}
          <div className={styles.recoHeader}>
            <div style={{ flex: 1 }}>
              <div className={styles.recoHeaderLabel}>Recomendado para você</div>
            </div>
            <span className={styles.recoBadge}>✨ recomendado</span>
          </div>

          {/* Body */}
          <div className={styles.recoBody}>
            {/* Modo principal */}
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span className={styles.recoEmoji}>{mainMode.emoji}</span>
              <span className={styles.recoName}>{mainMode.name}</span>
            </div>

            {/* Por que usar agora */}
            <div className={styles.recoMotivo}>
              <div className={styles.recoMotivoLabel}>Por que usar agora</div>
              {selectedEstado.motivo}
            </div>

            {/* Botão principal */}
            <button
              className={styles.recoUseBtn}
              onClick={() => onSelect(selectedEstado.modeId, selectedEstado.id)}
            >
              Usar {mainMode.emoji} {mainMode.name} →
            </button>
          </div>

          {/* Alternativa */}
          {altMode && (
            <div className={styles.altSection}>
              <button
                className={styles.altToggle}
                onClick={() => setShowAlt((v) => !v)}
              >
                Ver alternativa
                <span className={`${styles.altArrow} ${showAlt ? styles.altArrowOpen : ""}`}>▼</span>
              </button>

              {showAlt && (
                <div className={styles.altCard}>
                  <span className={styles.altEmoji}>{altMode.emoji}</span>
                  <div className={styles.altInfo}>
                    <div className={styles.altName}>{altMode.name}</div>
                    <div className={styles.altMotivo}>{selectedEstado.motivoAlt}</div>
                  </div>
                  <button
                    className={styles.altUseBtn}
                    onClick={() => onSelect(selectedEstado.modeIdAlt, selectedEstado.id)}
                  >
                    Usar este
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Pular */}
      <div className={styles.skipRow}>
        <button className={styles.skipBtn} onClick={onSkip}>
          Pular / já sei o que quero →
        </button>
      </div>
    </div>
  );
}
