/**
 * Mapeamento: estado emocional/energético → modo(s) de apoio recomendado(s)
 * Editável centralmente — sem necessidade de backend para o MVP.
 */
export const ESTADOS = [
  {
    id: "travado",
    emoji: "🧱",
    label: "Travado",
    modeId: "ler_diario",
    motivo: "Ler o diário ajuda a destravar pensamentos e criar impulso inicial.",
    modeIdAlt: "momentum",
    motivoAlt: "Sessões de 5 min quebram a inércia sem exigir foco prolongado.",
  },
  {
    id: "cansado",
    emoji: "😴",
    label: "Cansado",
    modeId: "meditar",
    motivo: "Um timer de meditação curto recarrega energia sem exigir esforço.",
    modeIdAlt: "agua",
    motivoAlt: "Hidratar-se é a tarefa mais fácil e já é uma conquista.",
  },
  {
    id: "ansioso",
    emoji: "😰",
    label: "Ansioso",
    modeId: "espresso",
    motivo: "Sprints de 25 min com foco claro reduzem a sensação de sobrecarga.",
    modeIdAlt: "esticar",
    motivoAlt: "5 min de alongamento liberam tensão física antes de começar.",
  },
  {
    id: "sem_foco",
    emoji: "🌫️",
    label: "Sem foco",
    modeId: "momentum",
    motivo: "5 minutos são o suficiente para criar tração sem precisar de concentração.",
    modeIdAlt: "music",
    motivoAlt: "A música certa cria um estado de foco sem esforço consciente.",
  },
  {
    id: "energizado",
    emoji: "⚡",
    label: "Energizado",
    modeId: "rpg",
    motivo: "Transforma sua energia em progresso gamificado com classes e missões.",
    modeIdAlt: "espresso",
    motivoAlt: "Canaliza a energia em sprints de alta intensidade.",
  },
];
